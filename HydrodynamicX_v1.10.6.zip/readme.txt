安裝python 3.10
安裝適合自己的IDE (推薦Code)

在終端機裡面輸入：
pip install discord
pip install python-dotenv
pip install py-cord
pip install pycord
pip install requests

去discord developers裡面建立機器人
複製金鑰 (token)
貼在.env裡面

新增log.txt在資料夾裡
新增memos.txt在資料夾裡
執行HydrodynamicX

HydrodynamicX = HydrodynamicXperiments = 流體力學.實驗版

@nKai.Lab / feat.JT.0